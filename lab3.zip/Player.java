public class Player{
	private Card[] deck;
	private int start = -1;

	public void give(Card next){//Добавляем карту в руку (идем до конца, отдаем id новой последней карты нынешней последней карте)
		if(start == -1){//Если нет первой карты, то устанавливаем в качестве первой пришедшую карту
			start = next.getNext();
		}else{
			int i = start;
			while(deck[i].getNext()!=-1){//идем до последней карты
				i = deck[i].getNext();
			}
			deck[i].setNext(next.getNext());//нынешней последней карте в next устанавливаем id новой последней
		}
		next.setNext(-1);//делаем пришедшую карту последней
	}

	public void setDeck(Card[] d){//Установка ссылки на колоду
		deck = d;
	}

	public void print(){//вывод руки игрока
		int curr = start;
		Card tmp;
		do{
			tmp = deck[curr];//Берем из колоды карту
			curr = tmp.getNext();//Запоминаем номер следующей
			tmp.printCard();//Выводим
		}while(curr!=-1);
	}
}