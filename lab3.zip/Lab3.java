/*
Колода карт 
	Значение 6-A
	Масть (Hearts, Diamonds, Clubs, Spades)

	36 карт

Задачи:
	Перемешать колоду
	Раздать карты 2 игрокам (через 1)

итог:
	Вывести колоду
	Перемешать
	Вывести
	Раздать игрокам
	Вывести обе у игроков
*/

class Lab3{

	public static void main(String[] args){ 
		Deck deck = new Deck();
		Player p1 = new Player();
		Player p2 = new Player();

		System.out.println("Deck:");
		deck.print();

		deck.shuffle(100);//Перемешать колоду 100 раз

		System.out.println("\nShuffled deck:");
		deck.print();

		deck.destribute(p1,p2);//раздать 2 игрокам

		System.out.println("\nPlayer 1 cards:");
		p1.print();
		System.out.println("\nPlayer 2 cards:");
		p2.print();
	}

}