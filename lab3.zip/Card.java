public class Card{
	private int num;//идентификатор пары номинал-масть (6 = Q of Hearts)
	private int next = -1;//id следующей карты в руке игрока

	public Card(int a){
		num = a;
	}

	public void setNext(int a){//Установка id следующей карты
		next = a;
	}

	public int getNext(){//Возврат id следующей карты
		return next;
	}

	public void printCard(){//Вывод карты
		if(num<9){
			System.out.println(formatСard(num) + " of Hearts");
		}else if(num<18){
			System.out.println(formatСard(num-9) + " of Diamonds");
		}else if(num<27){
			System.out.println(formatСard(num-18) + " of Clubs");
		}else{
			System.out.println(formatСard(num-27) + " of Spades");
		}
		
	}

	private String formatСard(int a){//Форматирование номинала карты
		switch(a){
			case 8:
				return "A";
			case 7:
				return "K";
			case 6:
				return "Q";
			case 5:
				return "J";
			default:
				return a+6+"";
		}
	}
}