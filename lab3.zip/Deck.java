import java.util.Random; 
public class Deck{
	private Card[] deck = new Card[36];//колода - массив из всех карт

	public Deck(){
		for(int i=0;i<36;i++){
			deck[i] = new Card(i);	
		}
	}

	public void print(){//Вывод массива кард
		for(Card card: deck){
			card.printCard();
		}
	}

	public void shuffle(int n){//Перемешивание (обмен местами 2 случайных карт n раз)
		Card tmp;
		int id0,id1;
		Random r = new Random();

		for (int i=0;i<n;i++){
			id0 = r.nextInt(36);
			id1 = r.nextInt(36);

			tmp = deck[id0];
			deck[id0] = deck[id1];
			deck[id1] = tmp;
		}
	}

	public void destribute(Player a, Player b){//Раздача карт
		a.setDeck(deck);//передаем ссылку на массив колоды
		b.setDeck(deck);//передаем ссылку на массив колоды
		for (int i=0;i<36;i+=2){
			deck[i].setNext(i);//в next карте передаем id себя-же
			deck[i+1].setNext(i+1);//в next карте передаем id себя-же
			a.give(deck[i]);//отдаем игроку id карты
			b.give(deck[i+1]);//отдаем игроку id карты
		}
	}
}